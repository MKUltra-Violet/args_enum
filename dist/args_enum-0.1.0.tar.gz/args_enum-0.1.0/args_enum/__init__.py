
__version__ = '{MAJOR}.{MINOR}.{PATCH}'.format(
    MAJOR = 0,
    MINOR = 1,
    PATCH = 0
)